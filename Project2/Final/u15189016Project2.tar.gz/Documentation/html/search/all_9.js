var searchData=
[
  ['popcase',['popCase',['../classDTreeNode.html#ae8a78c575b1496159a8fe4d8d2d1196a',1,'DTreeNode']]],
  ['prune',['prune',['../classContinuousDT.html#acacb9c899b06ae26f6697d9eebfb9f90',1,'ContinuousDT::prune()'],['../classDiscreteDT.html#aad5858661b17f84c575f62d00e8ae57b',1,'DiscreteDT::prune()']]]
];
