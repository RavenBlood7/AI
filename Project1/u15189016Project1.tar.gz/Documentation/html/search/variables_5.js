var searchData=
[
  ['playernumber',['playerNumber',['../classPlayer.html#adfea67ca8c4a03b59fee1bb09789f1bc',1,'Player']]]
];
