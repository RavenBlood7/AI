var searchData=
[
  ['direction',['direction',['../classMove.html#ac22c497cdb30dcce26b47400973fc154',1,'Move']]]
];
