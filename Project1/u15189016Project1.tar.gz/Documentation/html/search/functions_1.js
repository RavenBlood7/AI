var searchData=
[
  ['board',['Board',['../classBoard.html#af23f785e7c9d49271672c79c09cfa4e6',1,'Board']]]
];
