var searchData=
[
  ['aiplayer',['AIPlayer',['../classAIPlayer.html',1,'']]],
  ['aiplayer_2eh',['aiplayer.h',['../aiplayer_8h.html',1,'']]],
  ['aisettings',['AISettings',['../classAISettings.html',1,'']]],
  ['alphabetapruning',['alphaBetaPruning',['../classGameTree.html#a5dee6b86e6650d4339a03c2e84781413',1,'GameTree']]],
  ['assessstate',['assessState',['../classUser.html#a7425022cb54094e4e6e7bbc5ee734909',1,'User']]]
];
