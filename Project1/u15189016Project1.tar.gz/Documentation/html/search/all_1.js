var searchData=
[
  ['board',['Board',['../classBoard.html',1,'Board'],['../classBoard.html#aeb6adf23faa34599974ebda04f3b475b',1,'Board::board()'],['../classBoard.html#af23f785e7c9d49271672c79c09cfa4e6',1,'Board::Board(const Board &amp;other)']]]
];
