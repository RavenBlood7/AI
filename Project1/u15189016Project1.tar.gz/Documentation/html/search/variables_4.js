var searchData=
[
  ['ismaxnode',['isMaxNode',['../classState.html#aca086730625b739e264d6f1d77bcf43f',1,'State']]],
  ['isnamuastop',['isNamuaStop',['../classMove.html#a85f8b5f50a52e89a7cafc5196f0e54cb',1,'Move']]],
  ['istakasahouse',['isTakasaHouse',['../classMove.html#a0d75f22bb940cf3225affa915d7704cb',1,'Move']]]
];
