var searchData=
[
  ['senddata',['sendData',['../classGame.html#a727856085f92d0bea818e25d7e67bc08',1,'Game']]],
  ['setbutton',['setButton',['../classGUIBoard.html#ab43224559689559deacf1cdfedbf9cc0',1,'GUIBoard']]],
  ['setcurdata',['setCurData',['../classGame.html#a94a70a2007bf4355329aa6d85264d4ff',1,'Game']]],
  ['sethand',['setHand',['../classGUIBoard.html#ac3c1aab57acf09100cc4a57957bbd73b',1,'GUIBoard']]],
  ['sow',['sow',['../classBoard.html#a98fa56cfb48413a5733654d0cc187723',1,'Board::sow()'],['../classGUIBoard.html#a2a828b92689f77a5ffae52fcfc8b69c7',1,'GUIBoard::sow()']]],
  ['sowleftright',['sowLeftRight',['../classUser.html#a80ccbd1a91d0d67ec7d644cdc9bcb695',1,'User']]]
];
