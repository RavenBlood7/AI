var searchData=
[
  ['initialize',['initialize',['../classGame.html#abeb71053e90116938dd04f427c0ff5d4',1,'Game']]],
  ['islosingposition',['isLosingPosition',['../classBoard.html#adf54cfab0447f8f75f12b59b9033ae2b',1,'Board']]],
  ['isnamua',['isNamua',['../classBoard.html#a3fba772957d75edb79c36e14db5e8056',1,'Board']]],
  ['ispvai',['isPvAI',['../classGame.html#acbbf11cccd320ddbf68d3825175e33c6',1,'Game']]],
  ['istakasa',['isTakasa',['../classBoard.html#a51a400463a4bc18c5f6bdeb3690e6319',1,'Board']]],
  ['istakasanyumba',['isTakasaNyumba',['../classBoard.html#afd82db1e576d11324cf7def5061a1500',1,'Board']]]
];
