var searchData=
[
  ['initaivsai',['initAIvsAI',['../classGame.html#ad9cd10feac249b4a12d52d5ff6f439c8',1,'Game']]],
  ['initialize',['initialize',['../classGame.html#abeb71053e90116938dd04f427c0ff5d4',1,'Game']]],
  ['initpvsai',['initPvsAI',['../classGame.html#a832f541e03d03e0f9a35a51783092ae7',1,'Game']]],
  ['initpvsp',['initPvsP',['../classGame.html#a6c53d953f41a861ce8c253770ffe85f7',1,'Game']]],
  ['islosingposition',['isLosingPosition',['../classBoard.html#adf54cfab0447f8f75f12b59b9033ae2b',1,'Board']]],
  ['ismaxnode',['isMaxNode',['../classState.html#aca086730625b739e264d6f1d77bcf43f',1,'State']]],
  ['isnamua',['isNamua',['../classBoard.html#a3fba772957d75edb79c36e14db5e8056',1,'Board']]],
  ['isnamuastop',['isNamuaStop',['../classMove.html#a85f8b5f50a52e89a7cafc5196f0e54cb',1,'Move']]],
  ['ispvai',['isPvAI',['../classGame.html#acbbf11cccd320ddbf68d3825175e33c6',1,'Game']]],
  ['istakasa',['isTakasa',['../classBoard.html#a51a400463a4bc18c5f6bdeb3690e6319',1,'Board']]],
  ['istakasahouse',['isTakasaHouse',['../classMove.html#a0d75f22bb940cf3225affa915d7704cb',1,'Move']]],
  ['istakasanyumba',['isTakasaNyumba',['../classBoard.html#afd82db1e576d11324cf7def5061a1500',1,'Board']]]
];
