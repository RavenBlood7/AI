var searchData=
[
  ['children',['children',['../classState.html#a55b94ec04505ac9254a8e5e8a2e2a40f',1,'State']]],
  ['col',['col',['../classMove.html#afec68e3ba3346431f510a825797f1dc0',1,'Move']]]
];
