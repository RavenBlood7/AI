var searchData=
[
  ['take',['take',['../classBoard.html#a0f24e8798e0b138d667353943fc690e8',1,'Board::take()'],['../classGUIBoard.html#a14a3e02072c345b376813d8f82d4ff60',1,'GUIBoard::take()']]],
  ['taketurn',['takeTurn',['../classUser.html#a54e6a3f579223e72651f4cc630ac654e',1,'User']]]
];
