var searchData=
[
  ['capture',['capture',['../classBoard.html#a566a857bfcaea3c8ce1e11b3c8c9f2a9',1,'Board::capture()'],['../classGUIBoard.html#aa525ddbf1235b2b6aa7138103cbc2ca2',1,'GUIBoard::capture()'],['../classUser.html#a274f187a40145ce36ec805eb3ba656d4',1,'User::capture()']]]
];
