var searchData=
[
  ['row',['row',['../classMove.html#a078eb7da4c5a1bd0b9810453b1c25036',1,'Move']]]
];
