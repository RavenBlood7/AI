var searchData=
[
  ['board',['board',['../classBoard.html#aeb6adf23faa34599974ebda04f3b475b',1,'Board']]]
];
