var searchData=
[
  ['stack1',['stack1',['../classBoard.html#a07917499092ed8106f8db67019132b29',1,'Board']]],
  ['stack2',['stack2',['../classBoard.html#afa5399be8a3cedc417ae88ae0dcb98c1',1,'Board']]]
];
