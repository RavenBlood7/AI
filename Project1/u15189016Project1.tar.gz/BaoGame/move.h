#ifndef MOVE_H
#define MOVE_H

class Move
{
public:
    int row;
    int col;
    bool direction;
    bool isTakasaHouse;
    bool isNamuaStop;
    Move();
};

#endif // MOVE_H
