#include "move.h"

Move::Move()
{
}
